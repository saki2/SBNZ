package com.ftn.sbnz.service.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.drools.decisiontable.ExternalSpreadsheetCompiler;
import org.drools.template.ObjectDataCompiler;
import org.junit.jupiter.api.Test;
import org.kie.api.builder.Message;
import org.kie.api.builder.Results;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.internal.utils.KieHelper;

import com.ftn.sbnz.model.Alarm;
import com.ftn.sbnz.model.LogEntry;
import com.ftn.sbnz.model.LogType;


public class TemplateRuleTest {


    //@Test
    public void testAttackDetectionWithSpreadsheet() {
        InputStream template = TemplateRuleTest.class.getResourceAsStream("/template/template.drt");
        InputStream data = TemplateRuleTest.class.getResourceAsStream("/template/attack_data.xlsx");
        
        ExternalSpreadsheetCompiler converter = new ExternalSpreadsheetCompiler();
        System.out.println(converter);
        String drl = converter.compile(data, template, 1, 1); // Adjust the rows and columns accordingly

        System.out.println(drl);

        KieSession ksession = createKieSessionFromDRL(drl);

        performTest(ksession);
    }

    //@Test
    public void listAllResources() {
        try {
            String absolutePath = "D:/Programiranje/Cetvrta godina/Drugi semestar/SISTEMI BAZIRANI NA ZNANJU/Vezbe/SOV/Kostur/IME_PREZIME_BROJINDEKSA_GRUPA/sbnz-integracija-projekta/kjar/src\\main/resources/rules/template";
            Path path = Paths.get(absolutePath);
            
            try (Stream<Path> walk = Files.walk(path)) {
                walk.filter(Files::isRegularFile)
                    .forEach(System.out::println);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testAttackDetectionWithObjects() {
        String absolutePath = "D:/Programiranje/Cetvrta godina/Drugi semestar/SISTEMI BAZIRANI NA ZNANJU/Vezbe/SOV/Kostur/IME_PREZIME_BROJINDEKSA_GRUPA/sbnz-integracija-projekta/kjar/src\\main/resources/rules/template";
        try (InputStream template = Files.newInputStream(Paths.get(absolutePath))) {
            System.out.println("TEMPLATE");
            System.out.println(template);
            List<Map<String, Object>> data = new ArrayList<>();
            data.add(createDataMap("SQL Injection", "SQL_INJECTION"));
            data.add(createDataMap("Phishing", "PHISHING"));
            data.add(createDataMap("XSS Attack", "XSS_ATTACK"));
            data.add(createDataMap("Dependency Injection", "DEPENDENCY_INJECTION"));
            data.add(createDataMap("Trojan", "TROJAN"));
            data.add(createDataMap("Unauthorized Access", "UNAUTHORIZED_ACCESS"));
            data.add(createDataMap("Man In The Middle", "MITM"));
            data.add(createDataMap("Ransomware", "RANSOMWARE"));
            data.add(createDataMap("Malware", "MALWARE"));

            ObjectDataCompiler converter = new ObjectDataCompiler();
            String drl = converter.compile(data, template);

            System.out.println(drl);

            KieSession ksession = createKieSessionFromDRL(drl);

            performTest(ksession);
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    private Map<String, Object> createDataMap(String keyword, String threatType) {
        Map<String, Object> map = new HashMap<>();
        map.put("keyword", keyword);
        map.put("threatType", threatType);
        return map;
    }

    private void performTest(KieSession ksession) {
        LogEntry logEntry1 = new LogEntry(1, new Date(), "source1", "192.168.0.1", LogType.SystemLog, "Possible SQL Injection detected");
        LogEntry logEntry2 = new LogEntry(2, new Date(), "source2", "192.168.0.2", LogType.SystemLog, "Suspicious activity: Phishing attempt");

        ksession.insert(logEntry1);
        ksession.insert(logEntry2);

        ksession.fireAllRules();

        List<Alarm> alarms = new ArrayList<>();
        for (Object obj : ksession.getObjects()) {
            if (obj instanceof Alarm) {
                alarms.add((Alarm) obj);
            }
        }

        assertEquals(2, alarms.size());
    }

    private KieSession createKieSessionFromDRL(String drl){
        KieHelper kieHelper = new KieHelper();
        kieHelper.addContent(drl, ResourceType.DRL);
        
        Results results = kieHelper.verify();
        
        if (results.hasMessages(Message.Level.WARNING, Message.Level.ERROR)){
            List<Message> messages = results.getMessages(Message.Level.WARNING, Message.Level.ERROR);
            for (Message message : messages) {
                System.out.println("Error: "+message.getText());
            }
            
            throw new IllegalStateException("Compilation errors were found. Check the logs.");
        }
        
        return kieHelper.build().newKieSession();
    }

   
}
