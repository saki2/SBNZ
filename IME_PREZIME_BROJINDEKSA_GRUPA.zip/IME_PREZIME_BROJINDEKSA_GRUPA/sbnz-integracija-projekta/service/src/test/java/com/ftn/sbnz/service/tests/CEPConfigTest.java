package com.ftn.sbnz.service.tests;

import com.ftn.sbnz.model.Alarm;
import com.ftn.sbnz.model.LogEntry;
import com.ftn.sbnz.model.LogType;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;





public class CEPConfigTest {

    private KieSession kieSession;

    @BeforeEach
    public void setup() {
        KieServices kieServices = KieServices.Factory.get();
        KieContainer kieContainer = kieServices.getKieClasspathContainer();
        kieSession = kieContainer.newKieSession("cep");

    }

    @Test
    public void testDOSDetection() {

        LogEntry logEntry = null;
        for (int i = 0; i < 55; i++) {
            logEntry = new LogEntry(i, new Date(), "source1", "192.168.0.1", LogType.SystemLog, "Message: " + Integer.toString(i));
            kieSession.insert(logEntry);
        }

        kieSession.fireAllRules();

        List<Alarm> alarms = new ArrayList<>();
        for (Object obj : kieSession.getObjects()) {
            if (obj instanceof Alarm) {
                alarms.add((Alarm) obj);
            }
        }

        assertEquals(1, alarms.size());
    }

   
}
