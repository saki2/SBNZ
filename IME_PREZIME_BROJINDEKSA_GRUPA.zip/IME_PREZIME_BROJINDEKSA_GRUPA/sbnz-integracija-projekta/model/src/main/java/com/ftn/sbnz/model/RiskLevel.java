package com.ftn.sbnz.model;

public enum RiskLevel {
    Low,
    Medium,
    High,
    Critical
}