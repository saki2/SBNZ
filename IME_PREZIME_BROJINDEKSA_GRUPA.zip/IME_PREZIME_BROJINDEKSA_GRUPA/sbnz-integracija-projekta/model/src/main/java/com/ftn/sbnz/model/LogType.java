package com.ftn.sbnz.model;

public enum LogType {
    SecurityLog,
    NetworkLog,
    SystemLog,
    UserLog
}

